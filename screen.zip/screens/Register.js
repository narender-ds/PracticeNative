import { useNavigation } from '@react-navigation/native';
import react,{ useState,createRef } from 'react';
import {View, StyleSheet,Text ,Image ,ScrollView, Button, TextInput,  Keyboard,
   TouchableOpacity,Alert} from 'react-native';
   // import Loader from './Components/Loader';

    const Register= () => {
        const Navigation=useNavigation();
        const [name,setName] = useState('')
        const [email,setEmail] = useState('')
        const [phone,setPhone] = useState('')
        const [password,setPassword] = useState('')
        const [confirm_password,setConfirm_Password] = useState('')
        const [errortext, setErrortext] = useState('');
      
        // const [validEmail,setvalidEmail] = useState('false')
        const nameRef = createRef();
        const emailRef = createRef();
        const phoneRef = createRef();
        const passwordRef = createRef();
        const Confirm_passwordRef = createRef();
        const validate = () => {
          // console.log(text);
          setErrortext('');
       if (!name.trim() ) 
       { Alert.alert( "Register",'Please Enter Your Name',
       [
          {
             text: "Cancel",
             onPress: () => console.log("Cancel Pressed"),
             style: "cancel"
          },
          { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
       ]); return;
       } 

       if (!email.trim())
       { Alert.alert(  "Register",'Please Enter Your Email',
       [
          {
             text: "Cancel",
             onPress: () => console.log("Cancel Pressed"),
             style: "cancel"
          },
          { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
       ]); return;
       } 

      if(!phone.trim())
      { Alert.alert( "Register",'Please Enter Your Phone No.',
      [
      {
         text: "Cancel",
         onPress: () => console.log("Cancel Pressed"),
         style: "cancel"
      },
      { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
      ]); return;
      } 

      if(!password.trim())
      { Alert.alert( "Register",'Please Enter Your Password',
       [
          {
             text: "Cancel",
             onPress: () => console.log("Cancel Pressed"),
             style: "cancel"
          },
          { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
       ]); return;
      } 

      if(!confirm_password.trim()) 
      { Alert.alert( "Register",'Please Enter Confirm Password',
       [
          {
             text: "Cancel",
             onPress: () => console.log("Cancel Pressed"),
             style: "cancel"
          },
          { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
       ]); return;
       } {
           // alert('Empty fields are not allowed');
          
          
       }if(password!==confirm_password){ Alert.alert(  "Register",'Password and Confirm Password Must Be same',
         [
            {
               text: "Cancel",
               onPress: () => console.log("Cancel Pressed"),
               style: "cancel"
            },
            { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
         ]); 
         setName('')
         setEmail('')
         setPhone('')
         setPassword('')
         setConfirm_Password('')
        }
          
          let nameReg = /^[a-zA-Z ]{2,30}$/;
          let emailReg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w\w+)+$/;
          let phoneReg = /^[0]?[789]\d{9}$/;

          if (nameReg.test(name) === false)  { Alert.alert(  "Register",'Name is Not Valid',
          [
             {
                text: "Cancel",
                onPress: () => console.log("Cancel Pressed"),
                style: "cancel"
             },
             { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
          ]); return false;
       } 
        
          if (emailReg.test(email) === false)  { Alert.alert(  "Register",'Email is Not Valid',
          [
             {
                text: "Cancel",
                onPress: () => console.log("Cancel Pressed"),
                style: "cancel"
             },
             { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
          ]); return false;
       } 
          
          
          if (phoneReg.test(phone) === false)  { Alert.alert(  "Register",'Phone NO. is Not Valid',
          [
             {
                text: "Cancel",
                onPress: () => console.log("Cancel Pressed"),
                style: "cancel"
             },
             { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
          ]); return false;
       } 
 
         
          else{
            submit();
          }
          
        }
const submit=()=>{
      
    Alert.alert("Register"," Name:" + name + "Email:" + email + "\n" + "Phone:" + phone +  "password:" + password + "\n" + "Confirm Password:" +confirm_password,
    [
      {
         text: "Cancel",
         onPress: () => console.log("Cancel Pressed"),
         style: "cancel"
      },
      { text: "OK", onPress: () =>  {Navigation.navigate('Login',{ email: email,})}}
    ]);   
        setName('')
        setEmail('')
        setPhone('')
        setPassword('')
        setConfirm_Password('')
    };
    
   // props.navigate("Login");
 
    

   return(
      // <View style={{flex: 1, backgroundColor: '#7cccec'}}>
        <ScrollView > 

        <View style={styles.container}>
        <Text style={styles.textTitle}>Register </Text>
        <View style={{marginTop:20}}></View> 

        <Image 

        source={require('../assets/image/download.png')}  

        style={{width: 100, height: 100}} 

        />
      <View>
          <Text style={styles.textlabel}>Name</Text>
      </View>

      <TextInput
           value={name}
           onChangeText={(name) => setName(name)}
//   placeholder={'Name'}
      style={styles.input}
   
  underlineColorAndroid="#f000"
              ref={nameRef}
              returnKeyType="next"
              onSubmitEditing={() =>
               nameRef.current &&
               nameRef.current.focus()
              }
              blurOnSubmit={false}
/>

<View>
<Text style={styles.textlabel}>Email</Text>
</View>
<TextInput
  value={email}
  onChangeText={(email) => setEmail(email)}
  type="email"
  style={styles.input}
  underlineColorAndroid="#f000"
              ref={emailRef}
              returnKeyType="next"
               onSubmitEditing={() =>
               phoneRef.current &&
               phoneRef.current.focus()
              }
              blurOnSubmit={false}
/>

<View>
<Text style={styles.textlabel}>Phone</Text>
</View>
<TextInput
  value={phone}
  onChangeText={(phone) => setPhone(phone)}
  // minLength={10}
  maxLength={10}
  keyboardType="numeric"
//   placeholder={'Phone'}
  style={styles.input}
  underlineColorAndroid="#f000"
              ref={phoneRef}
              returnKeyType="next"
               onSubmitEditing={() =>
               passwordRef.current &&
               passwordRef.current.focus()
              }
              blurOnSubmit={false}
/>

<View>
<Text style={styles.Pass}>Password</Text>
</View>
<TextInput
  value={password}
  onChangeText={(password) => setPassword(password)}
  secureTextEntry
  style={styles.input}
  underlineColorAndroid="#f000"
              placeholderTextColor="#8b9cb5"
              autoCapitalize="sentences"
              ref={passwordRef}
              returnKeyType="next"
              onSubmitEditing={Keyboard.dismiss}
              blurOnSubmit={false}
/>

<View>
<Text style={styles.confirmPass}>Confirm_Password</Text>
</View>
        <TextInput
  value={confirm_password}
  onChangeText={(confirm_password) => setConfirm_Password(confirm_password)}
//   placeholder={'Confim_Password'}
  style={styles.input}
  underlineColorAndroid="#f000"
             autoCapitalize="sentences"
              ref={Confirm_passwordRef}
              returnKeyType="next"
              onSubmitEditing={Keyboard.dismiss}
              blurOnSubmit={false}
/>


        {/* <Button  
        onPress={validate}
        
         title="Submit"
    color="#000000"  style={styles.button} >
   
    </Button> */}
    {errortext != '' ? (
            <Text style={styles.errorTextStyle}>
              {errortext}
            </Text>
          ) : null}
          <TouchableOpacity
            style={styles.buttonStyle}
            activeOpacity={0.5}
            onPress={validate}>
            <Text style={styles.buttonTextStyle}>REGISTER</Text>
          </TouchableOpacity>
    </View>
     
    </ScrollView>
   //  </View>
  
   );     
};

 const styles = StyleSheet.create({
     container:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
        backgroundcolor:'red'
     },
     textTitle:{
        fontFamily:'foundation',
        fontSize:40,
        marginVerticle:10,
        color:'skyblue'
     },
     textbody:{
        fontFamily:'foundation',
        fontSize:16
     },
     input: {
      width: 250,
      height: 44,
      padding: 10,
      marginTop: 20,
      marginBottom: 10,
      backgroundColor: '#c0c0c0',
      borderRadius:8
    },
    button:{
        borderRadius:10
    },
    textlabel:{
        fontFamily:'bold',
        fontSize:15,
        position: 'absolute', right: 82,
        color:'black',
     
     },
     confirmPass:{
        fontFamily:'bold',
        fontSize:15,
        position: 'absolute', right: 0,
        color:'black',
     
     },
     Pass:{
        fontFamily:'bold',
        fontSize:15,
        position: 'absolute', right:55,
        color:'black',
     
     },
     buttonStyle: {
      backgroundColor: '#7D424E',
      borderWidth: 0,
      color: '#FFFFFF',
      borderColor: '#7D424E',
      width: 100 ,
      height: 40,
      alignItems: 'center',
      borderRadius: 10,
      marginLeft: 35,
      marginRight: 35,
      marginTop: 20,
      marginBottom: 20,
    },
    buttonTextStyle: {
      color: 'black',
      paddingVertical: 10,
      fontSize: 18,
      fontWeight:'bold'
    },
    
 });
 export  default Register;