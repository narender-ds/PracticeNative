import { useNavigation } from '@react-navigation/native';
import { useRoute} from '@react-navigation/native';
import react, { useState } from 'react';
import {View, StyleSheet,Text ,image ,ScrollView, Button, TextInput, Alert} from 'react-native';
// import Register from './screens/Register';

const Login = () => {

   const validate = () => {

   if (!email.trim())
   { Alert.alert(  "Register",'Please Enter Your Email',
   [
      {
         text: "Cancel",
         onPress: () => console.log("Cancel Pressed"),
         style: "cancel"
      },
      { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
   ]); return;
   } 

   if(!password.trim())
   { Alert.alert(  "Register",'Please Enter Your Password',
    [
       {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel"
       },
       { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
    ]); return;
   } 
   let emailReg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w\w+)+$/;
   if (emailReg.test(email) === false)  { Alert.alert(  "Register",'Email is Not Valid',
   [
      {
         text: "Cancel",
         onPress: () => console.log("Cancel Pressed"),
         style: "cancel"
      },
      { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
   ]); return false;
} 
   
   else{
      loginSubmit();
    }
   }
   const route=useRoute();
   const Navigation=useNavigation();
const [email,setEmail] = useState('')
const [password,setPassword] = useState('')


const loginSubmit =()=>{

Alert.alert(
   "Login",
   "Email:"+ email + " \n" + "Password:"+password,
   [
     {
       text: "Cancel",
       onPress: () => console.log("Cancel Pressed"),
       style: "cancel"
     },
     { text: "OK", onPress: () => {Navigation.navigate("Home")} }
   ]

 );
 setEmail('')
 setPassword('')

}



   return(
    <ScrollView Style={{backgroundcolor: 'red'}}> 
    <View style={styles.container}>
        <Text style={styles.textTitle}> Welcome </Text>
        <Text style={styles.textbody}>Login Here</Text>
  

        <View style={{marginTop:20}}></View>

        <TextInput
  value={email}
  onChangeText={(email) => setEmail(email)}
  placeholder={'Email'}
  /* <Text>{route.params.email}</Text> */
  
  style={styles.input}  
/>

<TextInput
  value={password}
  onChangeText={(password) => setPassword(password)}
  placeholder={'Password'}
  style={styles.input}
/>


        <Button  
        onPress={validate}
    
    title="Click Here"
    color="#0000ff"/>
     </View>

 
    </ScrollView>
  
   );     
};
 const styles = StyleSheet.create({
     container:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
        backgroundcolor:'red'
     },
     textTitle:{
        fontFamily:'foundation',
        fontSize:40,
        marginVerticle:10,
     },
     textbody:{
        fontFamily:'foundation',
        fontSize:16
     },
     input: {
      width: 250,
      height: 44,
      padding: 10,
      marginTop: 20,
      marginBottom: 10,
      backgroundColor: '#e8e8e8'
    },
    
 });
 export  default Login;