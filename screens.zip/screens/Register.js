import { useNavigation } from '@react-navigation/native';
import react,{ useState } from 'react';
import {View, StyleSheet,Text ,Image ,ScrollView, Button, TextInput, Alert} from 'react-native';


    const Register= () => {
        const Navigation=useNavigation();
        const [name,setName] = useState('')
        const [email,setEmail] = useState('')
        const [phone,setPhone] = useState('')
        const [password,setPassword] = useState('')
        const [confirm_password,setConfirm_Password] = useState('')
        // const [validEmail,setvalidEmail] = useState('false')
        
        const validate = () => {
          // console.log(text);
       if (!name.trim() ) 
       { Alert.alert(  "Register",'Please Enter Your Name',
       [
          {
             text: "Cancel",
             onPress: () => console.log("Cancel Pressed"),
             style: "cancel"
          },
          { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
       ]); return;
       } 

       if (!email.trim())
       { Alert.alert(  "Register",'Please Enter Your Email',
       [
          {
             text: "Cancel",
             onPress: () => console.log("Cancel Pressed"),
             style: "cancel"
          },
          { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
       ]); return;
       } 

      if(!phone.trim())
      { Alert.alert(  "Register",'Please Enter Your Phone No.',
      [
      {
         text: "Cancel",
         onPress: () => console.log("Cancel Pressed"),
         style: "cancel"
      },
      { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
      ]); return;
      } 

      if(!password.trim())
      { Alert.alert(  "Register",'Please Enter Your Password',
       [
          {
             text: "Cancel",
             onPress: () => console.log("Cancel Pressed"),
             style: "cancel"
          },
          { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
       ]); return;
      } 

      if(!confirm_password.trim()) 
      { Alert.alert(  "Register",'Please Enter Confirm Password',
       [
          {
             text: "Cancel",
             onPress: () => console.log("Cancel Pressed"),
             style: "cancel"
          },
          { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
       ]); return;
       } {
           // alert('Empty fields are not allowed');
          
          
       }if(password!==confirm_password){ Alert.alert(  "Register",'Password and Confirm Password Must Be same',
         [
            {
               text: "Cancel",
               onPress: () => console.log("Cancel Pressed"),
               style: "cancel"
            },
            { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
         ]); 
         setName('')
         setEmail('')
         setPhone('')
         setPassword('')
         setConfirm_Password('')
        }
          
          let nameReg = /^[a-zA-Z ]{2,30}$/;
          let emailReg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w\w+)+$/;
          let phoneReg = /^[0]?[789]\d{9}$/;

          if (nameReg.test(name) === false)  { Alert.alert(  "Register",'Name is Not Valid',
          [
             {
                text: "Cancel",
                onPress: () => console.log("Cancel Pressed"),
                style: "cancel"
             },
             { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
          ]); return false;
       } 
        
          if (emailReg.test(email) === false)  { Alert.alert(  "Register",'Email is Not Valid',
          [
             {
                text: "Cancel",
                onPress: () => console.log("Cancel Pressed"),
                style: "cancel"
             },
             { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
          ]); return false;
       } 
          
          
          if (phoneReg.test(phone) === false)  { Alert.alert(  "Register",'Phone NO. is Not Valid',
          [
             {
                text: "Cancel",
                onPress: () => console.log("Cancel Pressed"),
                style: "cancel"
             },
             { text: "OK", onPress: () =>  console.log("Cancel Pressed")}
          ]); return false;
       } 
 
         
          else{
            submit();
          }
        }
const submit=()=>{
      
    Alert.alert("Register"," Name:" + name + "Email:" + email + "\n" + "Phone:" + phone +  "password:" + password + "\n" + "Confirm Password:" +confirm_password,
    [
      {
         text: "Cancel",
         onPress: () => console.log("Cancel Pressed"),
         style: "cancel"
      },
      { text: "OK", onPress: () =>  {Navigation.navigate('Login',{ email: email,})}}
    ]);   
        setName('')
        setEmail('')
        setPhone('')
        setPassword('')
        setConfirm_Password('')
    };
    
   // props.navigate("Login");
 
    

   return(
        <ScrollView Style={{backgroundcolor: 'Blue'}}> 
        <View style={styles.container}>
        <Text style={styles.textTitle}>Register </Text>
        <View style={{marginTop:20}}></View> 

        <Image 

        source={require('../assets/image/download.png')}  

        style={{width: 100, height: 100}} 

        />
      <View>
          <Text style={styles.textlabel}>Name</Text>
      </View>

      <TextInput
           value={name}
           onChangeText={(name) => setName(name)}
//   placeholder={'Name'}
      style={styles.input}
/>

<View>
<Text style={styles.textlabel}>Email</Text>
</View>
<TextInput
  value={email}
  onChangeText={(email) => setEmail(email)}
  type="email"
  style={styles.input}
/>

<View>
<Text style={styles.textlabel}>Phone</Text>
</View>
<TextInput
  value={phone}
  onChangeText={(phone) => setPhone(phone)}
  // minLength={10}
  maxLength={10}
  keyboardType="numeric"
//   placeholder={'Phone'}
  style={styles.input}
/>

<View>
<Text style={styles.Pass}>Password</Text>
</View>
<TextInput
  value={password}
  onChangeText={(password) => setPassword(password)}
  secureTextEntry
  style={styles.input}
/>

<View>
<Text style={styles.confirmPass}>Confirm_Password</Text>
</View>
        <TextInput
  value={confirm_password}
  onChangeText={(confirm_password) => setConfirm_Password(confirm_password)}
//   placeholder={'Confim_Password'}
  style={styles.input}
/>


        <Button  
        onPress={validate}
        
         title="Submit"
    color="#000000"  style={styles.button} >
   
    </Button>
    
    </View>
     
    </ScrollView>
  
   );     
};

 const styles = StyleSheet.create({
     container:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
        backgroundcolor:'red'
     },
     textTitle:{
        fontFamily:'foundation',
        fontSize:40,
        marginVerticle:10,
        color:'skyblue'
     },
     textbody:{
        fontFamily:'foundation',
        fontSize:16
     },
     input: {
      width: 250,
      height: 44,
      padding: 10,
      marginTop: 20,
      marginBottom: 10,
      backgroundColor: '#c0c0c0',
      borderRadius:8
    },
    button:{
        borderRadius:10
    },
    textlabel:{
        fontFamily:'bold',
        fontSize:15,
        position: 'absolute', right: 82,
        color:'black',
     
     },
     confirmPass:{
        fontFamily:'bold',
        fontSize:15,
        position: 'absolute', right: 0,
        color:'black',
     
     },
     Pass:{
        fontFamily:'bold',
        fontSize:15,
        position: 'absolute', right:55,
        color:'black',
     
     },
    
 });
 export  default Register;